// أرشيف وليد — سكربت Google Drive
// 1) غيّر المفتاح هنا لأي كلمة سرية طويلة (نفس المفتاح تكتبه في التطبيق)
const KEY = 'غيّر-هذا-المفتاح-الآن';
const ROOT = 'أرشيف وليد';

function root_() { const it = DriveApp.getFoldersByName(ROOT); return it.hasNext() ? it.next() : DriveApp.createFolder(ROOT); }
function grp_(n) { const r = root_(), it = r.getFoldersByName(n); return it.hasNext() ? it.next() : r.createFolder(n); }
function out_(o) { return ContentService.createTextOutput(JSON.stringify(o)).setMimeType(ContentService.MimeType.JSON); }

function doPost(e) {
  try {
    const d = JSON.parse(e.postData.contents);
    if (d.key !== KEY) return out_({ error: 'المفتاح غير صحيح' });
    if (d.op === 'ping') return out_({ ok: true });
    if (d.op === 'group') { grp_(d.group); return out_({ ok: true }); }
    if (d.op === 'list') {
      const groups = [], files = [], fs = root_().getFolders();
      while (fs.hasNext()) {
        const g = fs.next(), n = g.getName(); groups.push(n);
        const it = g.getFiles();
        while (it.hasNext()) { const f = it.next(); files.push({ id: f.getId(), name: f.getName(), group: n }); }
      }
      return out_({ groups, files });
    }
    if (d.op === 'put') {
      const f = grp_(d.group), ex = f.getFilesByName(d.name);
      if (ex.hasNext()) return out_({ id: ex.next().getId() });
      const file = f.createFile(Utilities.newBlob(Utilities.base64Decode(d.data), 'image/jpeg', d.name));
      return out_({ id: file.getId() });
    }
    if (d.op === 'get') {
      return out_({ data: Utilities.base64Encode(DriveApp.getFileById(d.id).getBlob().getBytes()) });
    }
    return out_({ error: 'عملية غير معروفة' });
  } catch (err) { return out_({ error: String(err) }); }
}
